#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__      = "Randall Balestriero"
http://mindbigdata.com/opendb/index.html
