


for i in range(1, 22):
    filename = 'https://zenodo.org/record/2589280/files/TAU-urban-acoustic-scenes-2019-development.audio.{}.zip?download=1'.format(i)

