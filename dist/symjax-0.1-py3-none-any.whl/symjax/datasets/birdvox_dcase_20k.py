#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__      = "Randall Balestriero"
https://wp.nyu.edu/birdvox/codedata/#datasets
